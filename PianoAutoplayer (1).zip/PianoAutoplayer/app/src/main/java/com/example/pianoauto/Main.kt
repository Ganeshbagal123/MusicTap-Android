package com.example.pianoauto

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class Note(val t: Double, val p: Int)
class Tap(val t: Double, val x: Float, val y: Float)
data class Cfg(
    val first: Int, val keys: Int, val x0: Float, val kw: Float, val yw: Float, val yb: Float,
    val lead: Long, val speed: Double, val maxChord: Int,
    val shift: Int, val minNote: Int, val skipOut: Boolean
)

object Midi {
    val WHITE = setOf(0, 2, 4, 5, 7, 9, 11)

    fun parse(d: ByteArray): List<Note> {
        fun u8(i: Int) = d[i].toInt() and 0xFF
        fun u16(i: Int) = (u8(i) shl 8) or u8(i + 1)
        fun u32(i: Int) = (u8(i) shl 24) or (u8(i + 1) shl 16) or (u8(i + 2) shl 8) or u8(i + 3)
        require(d.size > 14 && String(d, 0, 4, Charsets.ISO_8859_1) == "MThd") { "This is not a MIDI file." }
        val nt = u16(10)
        var div = u16(12)
        if ((div and 0x8000) != 0) div = 480
        var o = 14
        val tempos = ArrayList<LongArray>()
        tempos.add(longArrayOf(0L, 500000L))
        val ons = ArrayList<LongArray>()
        for (k in 0 until nt) {
            if (o + 8 > d.size || String(d, o, 4, Charsets.ISO_8859_1) != "MTrk") break
            val end = minOf(o + 8 + u32(o + 4), d.size)
            o += 8
            var tick = 0L
            var rs = 0
            while (o < end) {
                var v = 0L
                while (true) { val b = u8(o++); v = (v shl 7) or (b and 127).toLong(); if ((b and 128) == 0) break }
                tick += v
                var s = u8(o)
                if (s == 0xFF) {
                    val ty = u8(o + 1); o += 2
                    var l = 0
                    while (true) { val b = u8(o++); l = (l shl 7) or (b and 127); if ((b and 128) == 0) break }
                    if (ty == 0x51 && l == 3) tempos.add(longArrayOf(tick, ((u8(o) shl 16) or (u8(o + 1) shl 8) or u8(o + 2)).toLong()))
                    o += l
                    continue
                }
                if (s == 0xF0 || s == 0xF7) {
                    o++
                    var l = 0
                    while (true) { val b = u8(o++); l = (l shl 7) or (b and 127); if ((b and 128) == 0) break }
                    o += l
                    continue
                }
                if ((s and 128) != 0) { rs = s; o++ } else s = rs
                val ty = s and 0xF0
                val ch = s and 15
                if (ty == 0xC0 || ty == 0xD0) { o++; continue }
                val a = u8(o); val vel = u8(o + 1); o += 2
                if (ty == 0x90 && vel > 0 && ch != 9) ons.add(longArrayOf(tick, a.toLong()))
            }
            o = end
        }
        tempos.sortBy { it[0] }
        val segT = LongArray(tempos.size)
        val segS = DoubleArray(tempos.size)
        val segU = LongArray(tempos.size)
        var sec = 0.0
        for (i in tempos.indices) {
            if (i > 0) sec += (tempos[i][0] - tempos[i - 1][0]) * tempos[i - 1][1] / 1e6 / div
            segT[i] = tempos[i][0]; segS[i] = sec; segU[i] = tempos[i][1]
        }
        fun t2s(t: Long): Double {
            var i = segT.size - 1
            while (i > 0 && segT[i] > t) i--
            return segS[i] + (t - segT[i]) * segU[i] / 1e6 / div
        }
        return ons.map { Note(t2s(it[0]), it[1].toInt()) }.sortedBy { it.t }
    }

    fun loadCfg(c: Context): Cfg? {
        val p = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)
        fun f(k: String) = p.getString(k, null)?.toFloatOrNull()
        val x0 = f("x0") ?: return null
        val kw = f("kw") ?: return null
        val yw = f("yw") ?: return null
        val yb = f("yb") ?: return null
        return Cfg(
            p.getString("first", "60")?.toIntOrNull() ?: 60,
            p.getString("keys", "14")?.toIntOrNull() ?: 14,
            x0, kw, yw, yb,
            p.getString("lead", "100")?.toLongOrNull() ?: 100L,
            p.getString("speed", "1.0")?.toDoubleOrNull() ?: 1.0,
            p.getString("maxChord", "3")?.toIntOrNull() ?: 3,
            p.getString("shift", "0")?.toIntOrNull() ?: 0,
            p.getString("minNote", "0")?.toIntOrNull() ?: 0,
            (p.getString("skip", "1") ?: "1") != "0"
        )
    }

    fun lastPitch(first: Int, keys: Int): Int {
        var n = 0; var q = first; var last = first
        while (n < keys) { if (q % 12 in WHITE) { n++; last = q }; q++ }
        return last
    }

    fun bestShift(notes: List<Note>, first: Int, keys: Int, minNote: Int): Pair<Int, Int> {
        val last = lastPitch(first, keys)
        val ps = notes.filter { it.p >= minNote }
        var bestS = 0
        var bestN = -1
        for (s in -36..36) {
            val n = ps.count { it.p + s in first..last }
            if (n > bestN || (n == bestN && Math.abs(s) < Math.abs(bestS))) { bestN = n; bestS = s }
        }
        return Pair(bestS, if (ps.isEmpty()) 0 else bestN * 100 / ps.size)
    }

    private fun widx(c: Cfg, p: Int) = (c.first until p).count { it % 12 in WHITE }

    private fun pos(c: Cfg, pp: Int, last: Int): Pair<Float, Float> {
        var p = pp
        while (p > last) p -= 12
        while (p < c.first) p += 12
        return if (p % 12 in WHITE) Pair(c.x0 + widx(c, p) * c.kw, c.yw)
        else Pair(c.x0 + (widx(c, p - 1) + 0.5f) * c.kw, c.yb)
    }

    fun buildTaps(all: List<Note>, c: Cfg): List<Tap> {
        val last = lastPitch(c.first, c.keys)
        val notes = all.filter { it.p >= c.minNote }.map { Note(it.t, it.p + c.shift) }
            .filter { !c.skipOut || (it.p >= c.first && it.p <= last) }
        val out = ArrayList<Tap>()
        var i = 0
        while (i < notes.size) {
            val t0 = notes[i].t
            val ps = ArrayList<Int>()
            var j = i
            while (j < notes.size && notes[j].t - t0 <= 0.03) { ps.add(notes[j].p); j++ }
            var u = ps.distinct().sorted()
            if (u.size > c.maxChord) u = if (c.maxChord > 1) listOf(u.first()) + u.takeLast(c.maxChord - 1) else listOf(u.last())
            val seen = HashSet<Pair<Float, Float>>()
            for (p in u) { val xy = pos(c, p, last); if (seen.add(xy)) out.add(Tap(t0, xy.first, xy.second)) }
            i = j
        }
        return out
    }
}

class PianoService : AccessibilityService() {
    companion object { @Volatile var inst: PianoService? = null }

    private val h = Handler(Looper.getMainLooper())
    private var running = false
    private var overlay: View? = null
    private var stopBtn: View? = null
    private val wm: WindowManager get() = getSystemService(Context.WINDOW_SERVICE) as WindowManager

    override fun onServiceConnected() { inst = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() { stop() }
    override fun onDestroy() { inst = null; stop(); removeOverlay(); super.onDestroy() }

    private fun overlayParams(w: Int, hgt: Int, flags: Int) = WindowManager.LayoutParams(
        w, hgt, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, flags, PixelFormat.TRANSLUCENT
    )

    private fun removeOverlay() { overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }; overlay = null }
    private fun removeStop() { stopBtn?.let { try { wm.removeView(it) } catch (_: Exception) {} }; stopBtn = null }

    fun stop() { running = false; h.removeCallbacksAndMessages(null); removeStop() }

    private fun showStop() {
        removeStop()
        val b = Button(this)
        b.text = "Stop"
        b.setOnClickListener { stop() }
        val lp = overlayParams(-2, -2, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE)
        lp.gravity = Gravity.TOP or Gravity.END
        lp.y = 120
        wm.addView(b, lp)
        stopBtn = b
    }

    fun startCalibration(keys: Int) {
        stop(); removeOverlay()
        val steps = listOf(
            "Tap the MIDDLE of the LEFTMOST white key",
            "Tap the MIDDLE of the RIGHTMOST white key",
            "Tap the UPPER part of any black key"
        )
        val tv = TextView(this)
        tv.textSize = 20f
        tv.setTextColor(Color.WHITE)
        tv.setBackgroundColor(0xCC000000.toInt())
        tv.setPadding(32, 32, 32, 32)
        tv.text = steps[0]
        val root = FrameLayout(this)
        root.setBackgroundColor(0x22000000)
        root.addView(tv, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        val pts = ArrayList<FloatArray>()
        root.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN) {
                pts.add(floatArrayOf(e.rawX, e.rawY))
                if (pts.size < 3) {
                    tv.text = steps[pts.size] + "\n(last tap: " + e.rawX.toInt() + ", " + e.rawY.toInt() + ")"
                } else {
                    val k = maxOf(2, keys)
                    getSharedPreferences("cfg", MODE_PRIVATE).edit()
                        .putString("x0", pts[0][0].toString())
                        .putString("yw", pts[0][1].toString())
                        .putString("kw", ((pts[1][0] - pts[0][0]) / (k - 1)).toString())
                        .putString("yb", pts[2][1].toString())
                        .apply()
                    removeOverlay()
                    Toast.makeText(this, "Keys saved.", Toast.LENGTH_LONG).show()
                }
            }
            true
        }
        wm.addView(
            root,
            overlayParams(-1, -1, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN)
        )
        overlay = root
    }

    fun play(taps: List<Tap>, c: Cfg, countdownMs: Long) {
        stop()
        if (taps.isEmpty()) return
        running = true
        showStop()
        val maxS = minOf(GestureDescription.getMaxStrokeCount(), 10)
        val chunks = ArrayList<List<Tap>>()
        var cur = ArrayList<Tap>()
        for (t in taps) {
            if (cur.isNotEmpty() && (cur.size >= maxS || t.t - cur[0].t > 3.0)) { chunks.add(cur); cur = ArrayList() }
            cur.add(t)
        }
        if (cur.isNotEmpty()) chunks.add(cur)
        runChunk(chunks, 0, SystemClock.uptimeMillis() + countdownMs, c)
    }

    private fun runChunk(ch: List<List<Tap>>, i: Int, start: Long, c: Cfg) {
        if (!running) return
        if (i >= ch.size) { stop(); return }
        val first = start + (ch[i][0].t / c.speed * 1000).toLong()
        val delay = maxOf(0L, first - c.lead - SystemClock.uptimeMillis())
        h.postDelayed({
            if (!running) return@postDelayed
            val now = SystemClock.uptimeMillis()
            val b = GestureDescription.Builder()
            var n = 0
            for (tp in ch[i]) {
                val off = start + (tp.t / c.speed * 1000).toLong() - now
                if (off < -250) continue
                val p = Path()
                p.moveTo(tp.x, tp.y)
                b.addStroke(GestureDescription.StrokeDescription(p, maxOf(0L, off), 50L))
                n++
            }
            if (n == 0) { runChunk(ch, i + 1, start, c); return@postDelayed }
            val cb = object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) { runChunk(ch, i + 1, start, c) }
                override fun onCancelled(g: GestureDescription?) { runChunk(ch, i + 1, start, c) }
            }
            if (!dispatchGesture(b.build(), cb, null)) runChunk(ch, i + 1, start, c)
        }, delay)
    }
}

class MainActivity : Activity() {
    private var notes: List<Note> = emptyList()
    private lateinit var status: TextView
    private val edits = LinkedHashMap<String, EditText>()

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    private fun save() {
        val e = getSharedPreferences("cfg", MODE_PRIVATE).edit()
        for ((k, v) in edits) e.putString(k, v.text.toString().trim())
        e.apply()
    }

    private fun start(list: List<Note>, c: Cfg) {
        val s = PianoService.inst ?: return toast("Turn on the accessibility service first.")
        if (c.first % 12 !in Midi.WHITE) return toast("The first note must be a white key.")
        toast("Starting in 5 seconds. Switch to Perfect Piano now.")
        s.play(Midi.buildTaps(list, c), c, 5000)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(40, 60, 40, 40)
        fun label(t: String, size: Float = 15f): TextView {
            val v = TextView(this); v.text = t; v.textSize = size; v.setPadding(0, 16, 0, 4); col.addView(v); return v
        }
        fun button(t: String, f: () -> Unit) {
            val v = Button(this); v.text = t; v.setAllCaps(false); v.setOnClickListener { f() }; col.addView(v)
        }
        fun input(key: String, text: String, def: String) {
            label(text); val e = EditText(this); e.setText(p.getString(key, def)); edits[key] = e; col.addView(e)
        }
        label("Piano Autoplayer", 24f)
        label("Open Perfect Piano in free play mode. Set up in order: 1, 2, then choose a file and press Play.")
        button("1. Turn on the accessibility service") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        input("first", "MIDI note of the leftmost white key (C3 = 48, C4 = 60)", "60")
        input("keys", "White keys visible on screen", "14")
        input("lead", "Tap early by (ms)", "100")
        input("speed", "Speed (1 = normal)", "1.0")
        input("maxChord", "Max keys pressed at once", "3")
        input("shift", "Transpose song by semitones (12 = one octave up)", "0")
        input("minNote", "Ignore notes below this MIDI note (60 = right hand only, 0 = none)", "0")
        input("skip", "Notes outside the keys: 1 = skip them, 0 = fold into range", "1")
        button("2. Calibrate keys") {
            save()
            val s = PianoService.inst
            if (s == null) toast("Turn on the accessibility service first.") else {
                toast("Open Perfect Piano now. Calibration starts in 6 seconds.")
                val keys = edits["keys"]!!.text.toString().toIntOrNull() ?: 14
                Handler(Looper.getMainLooper()).postDelayed({ s.startCalibration(keys) }, 6000)
            }
        }
        button("3. Choose MIDI file") {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE); i.type = "*/*"
            startActivityForResult(i, 1)
        }
        button("Auto-fit song to visible keys") {
            save()
            if (notes.isEmpty()) toast("Choose a MIDI file first.") else {
                val f = edits["first"]!!.text.toString().toIntOrNull() ?: 60
                val k = edits["keys"]!!.text.toString().toIntOrNull() ?: 14
                val mn = edits["minNote"]!!.text.toString().toIntOrNull() ?: 0
                val (sh, pct) = Midi.bestShift(notes, f, k, mn)
                edits["shift"]!!.setText(sh.toString())
                save()
                toast("Transpose set to " + sh + ". " + pct + "% of notes fit the visible keys.")
            }
        }
        button("Test: play a scale") {
            save()
            val c = Midi.loadCfg(this)
            if (c == null) toast("Calibrate the keys first.") else {
                val sc = ArrayList<Note>(); var q = c.first; var n = 0
                while (n < 8) { if (q % 12 in Midi.WHITE) { sc.add(Note(n * 0.5, q)); n++ }; q++ }
                start(sc, c.copy(shift = 0, minNote = 0))
            }
        }
        button("Play") {
            save()
            val c = Midi.loadCfg(this)
            if (c == null) toast("Calibrate the keys first.")
            else if (notes.isEmpty()) toast("Choose a MIDI file first.")
            else start(notes, c)
        }
        button("Stop") { PianoService.inst?.stop() }
        status = label("No file chosen.")
        val sv = ScrollView(this); sv.addView(col); setContentView(sv)
    }

    override fun onActivityResult(r: Int, res: Int, data: Intent?) {
        super.onActivityResult(r, res, data)
        if (r == 1 && res == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                notes = Midi.parse(bytes)
                status.text = notes.size.toString() + " notes loaded, " + (notes.lastOrNull()?.t ?: 0.0).toInt() + " seconds."
            } catch (e: Exception) {
                notes = emptyList(); status.text = e.message ?: "Could not read this file."
            }
        }
    }
}
