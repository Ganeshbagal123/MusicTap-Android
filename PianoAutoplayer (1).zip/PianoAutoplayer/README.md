# Piano Autoplayer (phone-only build)

Add these 7 files to a new GitHub repository (Add file > Create new file; typing "/" in the name creates folders):

1. .github/workflows/build.yml   (add this one LAST, it starts the build)
2. settings.gradle.kts
3. app/build.gradle.kts
4. app/src/main/AndroidManifest.xml
5. app/src/main/res/xml/accessibility_config.xml
6. app/src/main/res/values/strings.xml
7. app/src/main/java/com/example/pianoauto/Main.kt

Then open the Actions tab > Build APK > latest run > download the artifact "PianoAutoplayer-apk".
Unzip it, install app-debug.apk, then turn on Settings > Accessibility > Piano Autoplayer.
If the switch is greyed out: Settings > Apps > Piano Autoplayer > top-right menu > Allow restricted settings.

## v1.1
New settings: transpose, ignore low notes (right hand only), skip or fold notes outside the visible keys, and an Auto-fit button.
