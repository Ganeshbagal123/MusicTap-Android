package com.example.musictap

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class PianoAccessibilityService : AccessibilityService() {
    data class Note(val x: Int, val y: Int)

    private val handler = Handler(Looper.getMainLooper())
    private var sequenceToken = 0

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        isEnabled = true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // We do not inspect screen content. The service only sends gestures requested by the user.
    }

    override fun onInterrupt() {
        stopSequence()
    }

    override fun onDestroy() {
        isEnabled = false
        if (instance === this) instance = null
        stopSequence()
        super.onDestroy()
    }

    fun sendTap(x: Int, y: Int, durationMs: Long): Boolean {
        if (x < 0 || y < 0) return false
        val path = Path().apply {
            moveTo(x.toFloat(), y.toFloat())
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs.coerceIn(40, 1000)))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    fun playNotes(notes: List<Note>, durationMs: Long, gapMs: Long): Boolean {
        if (notes.isEmpty()) return false
        stopSequence()
        val token = sequenceToken
        val interval = durationMs.coerceIn(40, 1000) + gapMs.coerceIn(0, 5000)
        notes.forEachIndexed { index, note ->
            handler.postDelayed({
                if (token == sequenceToken) sendTap(note.x, note.y, durationMs)
            }, index * interval)
        }
        return true
    }

    fun stopSequence() {
        sequenceToken++
        handler.removeCallbacksAndMessages(null)
    }

    companion object {
        @Volatile var instance: PianoAccessibilityService? = null
            private set
        @Volatile var isEnabled: Boolean = false
            private set

        fun tap(x: Int, y: Int, durationMs: Long): Boolean =
            instance?.sendTap(x, y, durationMs) ?: false

        fun play(notes: List<Note>, durationMs: Long, gapMs: Int): Boolean =
            instance?.playNotes(notes, durationMs, gapMs.toLong()) ?: false

        fun stopSequence() {
            instance?.stopSequence()
        }
    }
}
