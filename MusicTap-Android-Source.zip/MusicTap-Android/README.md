# MusicTap Android – first touch automation prototype

This is a minimal Android Kotlin project. It uses an AccessibilityService with `dispatchGesture()` to send user-requested taps. It does not inspect the screen or control another app without the user enabling the service.

## Build on GitHub using a phone

1. Create a GitHub repository named `MusicTap-Android`.
2. Upload the contents of this project ZIP to the repository root. Make sure `.github/workflows/build-apk.yml` is included.
3. Use the repository's **Actions** tab. If prompted, enable GitHub Actions.
4. Run **Build MusicTap APK** using **Run workflow**, or push a commit to `main`.
5. Open the successful workflow run and download the `MusicTap-debug-apk` artifact.
6. Extract the artifact ZIP and install `app-debug.apk`.

## First test

1. Open MusicTap.
2. Tap **Enable MusicTap accessibility**.
3. In Android Accessibility settings, find **Downloaded apps / Installed apps > MusicTap Touch Controller** and enable it. Android will show a warning because accessibility services can perform gestures; enable only because this is your own app and you understand the permission.
4. Open Perfect Piano and keep its keyboard visible.
5. Determine the centre screen coordinates of C4, E4 and G4. Android coordinate tools vary by phone; Developer options > Pointer location can help identify coordinates.
6. Return to MusicTap and enter the X coordinates and shared Y coordinate.
7. Tap **Test one C4 tap**. Then try the four-note sequence.

## Important limitations

- This prototype sends short taps, not sustained piano key holds.
- You must calibrate coordinates for your display, orientation, game layout and navigation mode.
- Accessibility gesture injection may be rejected or interrupted by Android or the target app.
- The service does not read screen content.
- This is a debug prototype, not a signed Play Store release.
- If the app is in split-screen, floating-window mode, or the piano moves, recalibrate coordinates.
